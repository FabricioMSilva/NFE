
import React, { useState, useEffect } from 'react';
import { PublicClientApplication } from '@azure/msal-browser';
import './App.css';

// Configuração MSAL (Microsoft Authentication Library)
const msalConfig = {
  auth: {
    clientId: "14d82eec-204b-4c2f-b7e0-298a0ec13fa6", // Client ID público da Microsoft Graph Explorer
    authority: "https://login.microsoftonline.com/common",
    redirectUri: window.location.origin
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false,
  }
};

// Escopos necessários para acessar SharePoint via Graph API
const loginRequest = {
  scopes: [
    "https://graph.microsoft.com/Sites.Read.All",
    "https://graph.microsoft.com/Sites.ReadWrite.All",
    "https://graph.microsoft.com/Files.ReadWrite.All"
  ]
};

const msalInstance = new PublicClientApplication(msalConfig);

const SHAREPOINT_SITE_URL = 'https://michelingroup.sharepoint.com/sites/NF-RES';
const LIST_NAME = 'RONDA QUALIDADE';

export default function App() {
  const [account, setAccount] = useState(null);
  const [accessToken, setAccessToken] = useState(null);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [siteInfo, setSiteInfo] = useState(null);
  const [newMeasurement, setNewMeasurement] = useState({
    itemId: '',
    medicao: ''
  });

  useEffect(() => {
    // Verificar se já existe uma conta logada
    const accounts = msalInstance.getAllAccounts();
    if (accounts.length > 0) {
      setAccount(accounts[0]);
      acquireTokenSilent();
    }
  }, []);

  const login = async () => {
    try {
      setLoading(true);
      setError('');
      
      const loginResponse = await msalInstance.loginPopup(loginRequest);
      setAccount(loginResponse.account);
      setAccessToken(loginResponse.accessToken);
      setSuccess('✅ Login realizado com sucesso!');
      
      // Buscar informações do site SharePoint
      await getSiteInfo(loginResponse.accessToken);
      
    } catch (error) {
      setError(`❌ Erro no login: ${error.message}`);
      console.error('Erro no login:', error);
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    msalInstance.logoutPopup();
    setAccount(null);
    setAccessToken(null);
    setItems([]);
    setSiteInfo(null);
    setSuccess('👋 Logout realizado com sucesso!');
  };

  const acquireTokenSilent = async () => {
    try {
      const accounts = msalInstance.getAllAccounts();
      if (accounts.length === 0) return;

      const silentRequest = {
        ...loginRequest,
        account: accounts[0]
      };

      const response = await msalInstance.acquireTokenSilent(silentRequest);
      setAccessToken(response.accessToken);
      setAccount(response.account);
      
      // Buscar informações do site SharePoint
      await getSiteInfo(response.accessToken);
      
    } catch (error) {
      console.error('Erro ao obter token silencioso:', error);
      // Se falhar, forçar login interativo
      if (error.name === "InteractionRequiredAuthError") {
        login();
      }
    }
  };

  const callGraphAPI = async (endpoint, method = 'GET', body = null) => {
    if (!accessToken) {
      throw new Error('Token de acesso não disponível');
    }

    const response = await fetch(`https://graph.microsoft.com/v1.0${endpoint}`, {
      method,
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: body ? JSON.stringify(body) : null
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP ${response.status}: ${errorText}`);
    }

    return response.json();
  };

  const getSiteInfo = async (token = accessToken) => {
    try {
      setLoading(true);
      
      // Buscar site pelo hostname e path
      const hostname = 'michelingroup.sharepoint.com';
      const sitePath = '/sites/NF-RES';
      
      const siteData = await callGraphAPI(`/sites/${hostname}:${sitePath}`);
      setSiteInfo(siteData);
      setSuccess(`✅ Site encontrado: ${siteData.displayName}`);
      
      // Buscar listas do site
      await getSharePointLists(siteData.id);
      
    } catch (error) {
      setError(`❌ Erro ao buscar site: ${error.message}`);
      console.error('Erro ao buscar site:', error);
    } finally {
      setLoading(false);
    }
  };

  const getSharePointLists = async (siteId) => {
    try {
      const listsData = await callGraphAPI(`/sites/${siteId}/lists`);
      console.log('Listas disponíveis:', listsData.value);
      
      // Procurar pela lista específica
      const targetList = listsData.value.find(list => 
        list.displayName === LIST_NAME || 
        list.name === LIST_NAME ||
        list.displayName.includes('RONDA') ||
        list.displayName.includes('QUALIDADE')
      );

      if (targetList) {
        setSuccess(`✅ Lista encontrada: ${targetList.displayName}`);
        await getListItems(siteId, targetList.id);
      } else {
        setError(`❌ Lista "${LIST_NAME}" não encontrada. Listas disponíveis: ${listsData.value.map(l => l.displayName).join(', ')}`);
      }
      
    } catch (error) {
      setError(`❌ Erro ao buscar listas: ${error.message}`);
      console.error('Erro ao buscar listas:', error);
    }
  };

  const getListItems = async (siteId, listId) => {
    try {
      setLoading(true);
      
      const itemsData = await callGraphAPI(`/sites/${siteId}/lists/${listId}/items?expand=fields&$top=100`);
      
      // Transformar dados para formato compatível
      const transformedItems = itemsData.value.map(item => ({
        Id: item.id,
        Title: item.fields.Title || 'Sem título',
        Medicao: item.fields.Medicao || null,
        Created: item.createdDateTime,
        Modified: item.lastModifiedDateTime,
        ...item.fields
      }));

      setItems(transformedItems);
      setSuccess(`✅ ${transformedItems.length} itens carregados da lista!`);
      
    } catch (error) {
      setError(`❌ Erro ao buscar itens: ${error.message}`);
      console.error('Erro ao buscar itens:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateListItem = async () => {
    if (!newMeasurement.itemId || !newMeasurement.medicao) {
      setError('❌ Por favor, preencha o ID do item e a medição');
      return;
    }

    if (!siteInfo) {
      setError('❌ Informações do site não disponíveis');
      return;
    }

    try {
      setLoading(true);
      setError('');

      // Primeiro, encontrar a lista
      const listsData = await callGraphAPI(`/sites/${siteInfo.id}/lists`);
      const targetList = listsData.value.find(list => 
        list.displayName === LIST_NAME || 
        list.name === LIST_NAME ||
        list.displayName.includes('RONDA') ||
        list.displayName.includes('QUALIDADE')
      );

      if (!targetList) {
        throw new Error('Lista não encontrada');
      }

      // Atualizar o item
      const updateData = {
        fields: {
          Medicao: newMeasurement.medicao
        }
      };

      await callGraphAPI(`/sites/${siteInfo.id}/lists/${targetList.id}/items/${newMeasurement.itemId}`, 'PATCH', updateData);
      
      setSuccess(`✅ Medição atualizada com sucesso! Item ${newMeasurement.itemId}`);
      setNewMeasurement({ itemId: '', medicao: '' });
      
      // Recarregar a lista
      await getListItems(siteInfo.id, targetList.id);
      
    } catch (error) {
      setError(`❌ Erro ao atualizar medição: ${error.message}`);
      console.error('Erro ao atualizar:', error);
    } finally {
      setLoading(false);
    }
  };

  const openExcelOnline = () => {
    const excelUrl = 'https://michelingroup.sharepoint.com/sites/NF-RES/_layouts/15/doc.aspx?sourcedoc={946bb5f1-9684-4808-a682-9d8b893de42e}&action=edit';
    window.open(excelUrl, '_blank');
    setSuccess('📊 Planilha Excel Online aberta em nova aba!');
  };

  return (
    <div className="app">
      <header className="header">
        <h1>🧪 SharePoint via Microsoft Graph API</h1>
        <p>Integração com Azure AD e Microsoft Graph</p>
      </header>

      {!account ? (
        <div className="auth-section">
          <h3>🔐 Autenticação necessária</h3>
          <p>Faça login com sua conta Microsoft/Azure AD para acessar o SharePoint</p>
          <button 
            onClick={login} 
            disabled={loading}
            className="login-button"
          >
            {loading ? '⏳ Conectando...' : '🚀 Login com Microsoft'}
          </button>
        </div>
      ) : (
        <>
          <div className="user-info">
            <h3>👤 Usuário logado</h3>
            <p><strong>Nome:</strong> {account.name}</p>
            <p><strong>Email:</strong> {account.username}</p>
            <button onClick={logout} className="logout-button">
              🚪 Logout
            </button>
          </div>

          <div className="controls">
            <div className="action-buttons">
              <button onClick={() => getSiteInfo()} disabled={loading}>
                {loading ? '⏳ Carregando...' : '🔄 Recarregar Dados'}
              </button>
              <button onClick={openExcelOnline}>
                📊 Abrir Excel Online
              </button>
            </div>
          </div>

          <div className="measurement-update">
            <h3>📊 Atualizar Medição</h3>
            <div className="input-group">
              <input
                type="number"
                placeholder="ID do Item"
                value={newMeasurement.itemId}
                onChange={(e) => setNewMeasurement({...newMeasurement, itemId: e.target.value})}
              />
              <input
                type="text"
                placeholder="Valor da Medição"
                value={newMeasurement.medicao}
                onChange={(e) => setNewMeasurement({...newMeasurement, medicao: e.target.value})}
              />
              <button onClick={updateListItem} disabled={loading}>
                ✅ Atualizar via Graph API
              </button>
            </div>
          </div>

          {siteInfo && (
            <div className="site-info">
              <h3>🌐 Informações do Site</h3>
              <p><strong>Nome:</strong> {siteInfo.displayName}</p>
              <p><strong>URL:</strong> {siteInfo.webUrl}</p>
              <p><strong>ID:</strong> {siteInfo.id}</p>
            </div>
          )}

          <div className="items-section">
            <h3>📝 Itens da Lista ({items.length})</h3>
            <div className="items-grid">
              {items.map((item, index) => (
                <div key={item.Id || index} className="item-card">
                  <div className="item-header">
                    <span className="item-id">ID: {item.Id}</span>
                    <span className="item-title">{item.Title || 'Sem título'}</span>
                  </div>
                  <div className="item-content">
                    <div className="field">
                      <strong>Medição:</strong> 
                      <span className={item.Medicao ? 'has-value' : 'no-value'}>
                        {item.Medicao || 'Não informado'}
                      </span>
                    </div>
                    {item.Created && (
                      <div className="field">
                        <strong>Criado:</strong> {new Date(item.Created).toLocaleDateString('pt-BR')}
                      </div>
                    )}
                    {item.Modified && (
                      <div className="field">
                        <strong>Modificado:</strong> {new Date(item.Modified).toLocaleDateString('pt-BR')}
                      </div>
                    )}
                  </div>
                  <button 
                    className="quick-update"
                    onClick={() => setNewMeasurement({...newMeasurement, itemId: item.Id.toString()})}
                  >
                    🎯 Selecionar para Atualizar
                  </button>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {error && <div className="error">{error}</div>}
      {success && <div className="success">{success}</div>}

      <div className="info">
        <h3>ℹ️ Informações Técnicas</h3>
        <div className="info-grid">
          <div className="info-card">
            <h4>🔗 Método</h4>
            <p><code>Microsoft Graph API</code></p>
          </div>
          <div className="info-card">
            <h4>🔐 Autenticação</h4>
            <p><code>Azure AD (MSAL)</code></p>
          </div>
          <div className="info-card">
            <h4>📋 Lista</h4>
            <p><code>{LIST_NAME}</code></p>
          </div>
          <div className="info-card">
            <h4>🌐 Status</h4>
            <p>{account ? (items.length > 0 ? '✅ Conectado' : '🔄 Carregando') : '❌ Desconectado'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
